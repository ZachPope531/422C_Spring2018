package gofish_assn;

public class GoFishGame {

	public GoFishGame() {
		// TODO Auto-generated constructor stub
	}

}
