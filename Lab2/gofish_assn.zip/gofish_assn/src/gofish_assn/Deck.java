package gofish_assn;

import java.util.ArrayList;

import gofish_assn.Card.Suits;
import java.util.Random;

public class Deck {
	ArrayList<Card> deck = new ArrayList<Card> ();
	final int NUM_CARDS = 52;  //for this kind of deck
	
	//creates a new sorted deck
	public Deck() {
		
		
	}
	
	public void shuffle() {
		
	}
	
	
	public void printDeck() {

	}
	
	
	public Card dealCard() {
		
		Card c = new Card();
		
		return c;
		
	}
	

}
